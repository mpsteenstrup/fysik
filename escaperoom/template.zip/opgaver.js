const levels = [
    {
        title: "level 1:",
        description: "xx",
        answer: "xx",
        image: "xx",
        music: "xx"
    },
    {
        title: "level 2: ",
        description: "xx",
        answer: "xx",
        image: "xx",
        music: "xx"
    },
    {
        title: "xx",
        description: "xx",
        answer: "xx",
        image: "xx",
        music: "xx"
    },
    {
        title: "xx",
        description: "xx",
        answer: "xx",
        image: "xx",
        music: "xx"
    },
    {
        title: "xx",
        description: "xx",
        answer: "xx",
        image: "xx",
        music: "xx"
    }

];
